# eShopOnContainers
The content of this folder has been moved to the repository -  [eshop-mobile-client](https://github.com/dotnet-architecture/eshop-mobile-client)
