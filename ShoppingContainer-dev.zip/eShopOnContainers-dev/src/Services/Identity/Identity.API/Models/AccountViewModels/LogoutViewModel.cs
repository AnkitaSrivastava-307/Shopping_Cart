﻿namespace Microsoft.eShopOnContainers.Services.Identity.API.Models.AccountViewModels
{
    public record LogoutViewModel
    {
        public string LogoutId { get; set; }
    }
}